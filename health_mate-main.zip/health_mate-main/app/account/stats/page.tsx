import Link from "next/link";

function StatsPage() {
  return (
    <div>
      <Link className="" href="/account/">
        back
      </Link>
      <h1>StatsPage</h1>
    </div>
  );
}

export default StatsPage;
