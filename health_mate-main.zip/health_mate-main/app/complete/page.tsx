import Navigation from "@/components/Navigation";
import PhoneNavigation from "@/components/PhoneNavigation";
import React from "react";

function CompleteLogin() {
  return (
    <main>
      <Navigation></Navigation>
      <div>multip step form to complete login</div>
      {/* <PhoneNavigation selected="home" /> */}
    </main>
  );
}

export default CompleteLogin;
