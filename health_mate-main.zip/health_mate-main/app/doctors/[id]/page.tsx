import React from "react";

async function DoctorInfo(props: any) {
  return <div>DoctorInfo {props.params.id}</div>;
}

export default DoctorInfo;
