import React from "react";

async function Doctors() {
  return <div>list Doctors</div>;
}

export default Doctors;
