/** @type {import('next').NextConfig} */
const nextConfig = {
  experimental: {
    taint: true,
  },
};

module.exports = nextConfig;
