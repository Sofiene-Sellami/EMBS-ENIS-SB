import React from "react";

function Banner() {
  return <div>You need to complete your login</div>;
}

export default Banner;
