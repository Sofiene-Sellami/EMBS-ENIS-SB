drizzle ORM
supabase db
linting and formatting
tailwind + shadcn/ui

auth

https://github.com/marketplace/actions/supabase-cli-action

https://supabase.com/docs/reference/cli

https://supabase.com/blog/fetching-and-caching-supabase-data-in-next-js-server-components

https://supabase.com/docs/guides/database/connecting-to-postgres#serverless-apis

https://www.youtube.com/watch?v=w3LD0Z73vgU&list=PL5S4mPUpp4OtMhpnp93EFSo42iQ40XjbF&index=3

https://github.com/supabase/cli/issues/899
